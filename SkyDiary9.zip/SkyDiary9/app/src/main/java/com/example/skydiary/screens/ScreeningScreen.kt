package com.example.skydiary.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.skydiary.components.SkyButton
import com.example.skydiary.data.remote.repository.ScreeningResultRow
import com.example.skydiary.ui.theme.*

/**
 * DASS-21 in standard item order (1–21). ScreeningRepository relies on this order for subscale sums.
 * Wording is a draft; check against the validated Thai DASS-21 before research use.
 */
private val dassItems = listOf(
    "ฉันรู้สึกยากที่จะสงบจิตใจลง", "ฉันรู้สึกปากแห้งคอแห้ง", "ฉันแทบไม่รู้สึกอะไรดี ๆ เลย",
    "ฉันมีอาการหายใจผิดปกติ (หายใจเร็ว หอบ) แม้ไม่ได้ออกแรง", "ฉันพบว่ามันยากที่จะเริ่มลงมือทำสิ่งใดสิ่งหนึ่ง",
    "ฉันมีแนวโน้มที่จะตอบสนองเกินเหตุต่อสถานการณ์", "ฉันรู้สึกว่าร่างกายบางส่วนสั่น (เช่น มือสั่น)",
    "ฉันรู้สึกเสียพลังไปมากกับการวิตกกังวล", "ฉันกังวลกับเหตุการณ์ที่อาจทำให้ตื่นตระหนกและทำเรื่องน่าอาย",
    "ฉันรู้สึกว่าไม่มีอะไรให้หวังอีกต่อไป", "ฉันรู้สึกกระวนกระวายใจ", "ฉันรู้สึกผ่อนคลายได้ยาก",
    "ฉันรู้สึกจิตใจเหงาหงอย เศร้าซึม", "ฉันรู้สึกทนไม่ได้เวลามีอะไรมาขัดขวางสิ่งที่ฉันกำลังทำอยู่",
    "ฉันรู้สึกคล้ายจะตื่นตระหนก", "ฉันรู้สึกไม่มีความกระตือรือร้นต่อสิ่งใด",
    "ฉันรู้สึกเป็นคนไม่มีคุณค่า", "ฉันรู้สึกค่อนข้างฉุนเฉียวง่าย",
    "ฉันรับรู้ถึงการเต้นของหัวใจแม้ไม่ได้ออกแรง (เช่น ใจเต้นเร็ว ใจสั่น)",
    "ฉันรู้สึกกลัวโดยไม่มีเหตุผล", "ฉันรู้สึกว่าชีวิตไม่มีความหมาย"
)

private val scaleLabels = listOf(
    "0 = ไม่ตรงกับฉันเลย",
    "1 = ตรงกับฉันบ้าง หรือเกิดขึ้นเป็นบางครั้ง",
    "2 = ตรงกับฉัน หรือเกิดขึ้นบ่อย",
    "3 = ตรงกับฉันมาก หรือเกิดขึ้นบ่อยมากที่สุด"
)

@Composable
fun ScreeningScreen(
    saving: Boolean = false,
    errorMessage: String? = null,
    onClose: () -> Unit = {},
    onSubmit: (List<Int>) -> Unit = {}
) {
    val answers = remember { mutableStateListOf<Int?>().apply { repeat(21) { add(null) } } }
    var submitted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SkyBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 24.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text("✕", modifier = Modifier.clickable { onClose() }.padding(4.dp),
                fontSize = 26.sp, color = SkyDanger)
        }
        Text("แบบประเมิน DASS-21", fontFamily = Prompt, fontWeight = FontWeight.Bold,
            fontSize = 26.sp, color = SkyText)
        Spacer(Modifier.height(6.dp))
        Text("โปรดเลือกคำตอบที่ตรงกับตัวคุณในช่วง 1 สัปดาห์ที่ผ่านมา",
            fontFamily = Prompt, fontSize = 15.sp, color = SkyText)
        scaleLabels.forEach { Text(it, fontFamily = Prompt, fontSize = 13.sp, color = SkyHint) }
        Text("* เป็นการคัดกรองเบื้องต้น ไม่ใช่การวินิจฉัยโรค",
            fontFamily = Prompt, fontSize = 12.sp, color = SkyHint)
        Spacer(Modifier.height(16.dp))

        dassItems.forEachIndexed { index, item ->
            val missing = submitted && answers[index] == null
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(20.dp))
                    .background(SkyCard, RoundedCornerShape(20.dp))
                    .then(if (missing) Modifier.border(1.5.dp, SkyDanger, RoundedCornerShape(20.dp)) else Modifier)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text("${index + 1}. $item", fontFamily = Prompt, fontSize = 14.sp, color = SkyText)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    (0..3).forEach { score ->
                        val selected = answers[index] == score
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(if (selected) SkyPrimary else Color.White, CircleShape)
                                .border(1.5.dp, SkyBorder, CircleShape)
                                .clickable { answers[index] = score },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(score.toString(), fontFamily = Prompt, fontWeight = FontWeight.Bold,
                                fontSize = 16.sp, color = if (selected) Color.White else SkyText)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (submitted && answers.any { it == null }) {
            Text("กรุณาตอบให้ครบทั้ง 21 ข้อ", fontFamily = Prompt, fontSize = 13.sp, color = SkyDanger)
            Spacer(Modifier.height(8.dp))
        }
        if (errorMessage != null) {
            Text(errorMessage, fontFamily = Prompt, fontSize = 13.sp, color = SkyDanger)
            Spacer(Modifier.height(8.dp))
        }
        SkyButton(if (saving) "กำลังบันทึก..." else "ส่งแบบประเมิน", {
            submitted = true
            if (!saving && answers.all { it != null }) onSubmit(answers.map { it!! })
        })
        Spacer(Modifier.height(24.dp))
    }
}

private fun levelText(level: String?): String = when (level?.lowercase()) {
    null, "" -> "-"
    "normal" -> "ปกติ"
    "mild" -> "เล็กน้อย"
    "moderate" -> "ปานกลาง"
    "severe" -> "รุนแรง"
    "extremely_severe", "extremely severe" -> "รุนแรงมาก"
    else -> level
}

/** Shows saved results from SCREENING_RESULTS; levels come from the database trigger. */
@Composable
fun ScreeningResultScreen(
    results: List<ScreeningResultRow> = emptyList(),
    onClose: () -> Unit = {},
    onNew: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SkyBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 24.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text("✕", modifier = Modifier.clickable { onClose() }.padding(4.dp),
                fontSize = 26.sp, color = SkyDanger)
        }
        Text("ผลการประเมิน DASS-21", fontFamily = Prompt, fontWeight = FontWeight.Bold,
            fontSize = 26.sp, color = SkyText)
        Text("คะแนนดิบ 0–21 ต่อด้าน • ผลนี้ไม่ใช่การวินิจฉัยโรค",
            fontFamily = Prompt, fontSize = 13.sp, color = SkyHint)
        Spacer(Modifier.height(16.dp))

        if (results.isEmpty()) {
            Text("ยังไม่มีผลการประเมิน", fontFamily = Prompt, fontSize = 16.sp, color = SkyHint,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
        results.forEach { r ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(6.dp, RoundedCornerShape(28.dp))
                    .background(SkyCard, RoundedCornerShape(28.dp))
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text("วันที่ ${r.date}", fontFamily = Prompt, fontWeight = FontWeight.Bold,
                    fontSize = 15.sp, color = SkyText)
                Spacer(Modifier.height(6.dp))
                Text("ภาวะซึมเศร้า: ${r.depressionScore} (${levelText(r.depressionLevel)})",
                    fontFamily = Prompt, fontSize = 14.sp, color = SkyText)
                Text("ความวิตกกังวล: ${r.anxietyScore} (${levelText(r.anxietyLevel)})",
                    fontFamily = Prompt, fontSize = 14.sp, color = SkyText)
                Text("ความเครียด: ${r.stressScore} (${levelText(r.stressLevel)})",
                    fontFamily = Prompt, fontSize = 14.sp, color = SkyText)
                r.recommendation?.takeIf { it.isNotBlank() }?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it, fontFamily = Prompt, fontSize = 13.sp, color = SkyHint)
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(8.dp))
        SkyButton("ทำแบบประเมินอีกครั้ง", onNew)
    }
}

@Preview(showBackground = true, widthDp = 402, heightDp = 874)
@Composable
fun ScreeningPreview() {
    SkyDiaryTheme { ScreeningScreen() }
}
