package com.example.skydiary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.example.skydiary.components.DiaryRecord
import com.example.skydiary.components.calcStreak
import com.example.skydiary.components.todayDate
import com.example.skydiary.screens.AppNotification
import com.example.skydiary.screens.BehaviorScreen
import com.example.skydiary.screens.CalendarScreen
import com.example.skydiary.screens.ForgotPasswordScreen
import com.example.skydiary.screens.HomeScreen
import com.example.skydiary.screens.LoginScreen
import com.example.skydiary.screens.MoodScreen
import com.example.skydiary.screens.NotificationScreen
import com.example.skydiary.screens.ProfileScreen
import com.example.skydiary.screens.RegisterScreen
import com.example.skydiary.screens.SkyPhotoScreen
import com.example.skydiary.screens.SummaryScreen
import com.example.skydiary.ui.theme.SkyDiaryTheme

// บัญชีผู้ใช้ (เก็บในหน่วยความจำ หายเมื่อปิดแอป) ตอนมี database ให้แทนที่ด้วยการเรียกเซิร์ฟเวอร์
data class Account(
    val name: String,
    val phone: String,
    val email: String,
    val gender: String,
    val password: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SkyDiaryTheme {
                val accounts = remember { mutableStateListOf<Account>() }
                val records = remember { mutableStateListOf<DiaryRecord>() }
                var currentUser by remember { mutableStateOf<Account?>(null) }
                var resetEmail by remember { mutableStateOf<String?>(null) }
                var welcomeShown by remember { mutableStateOf(false) }

                var page by remember { mutableStateOf("login") }
                // หน้าที่เปิดกระดิ่งมา เพื่อให้ปุ่ม ✕ กลับถูกหน้า
                var pageBeforeBell by remember { mutableStateOf("home") }
                var loginError by remember { mutableStateOf<String?>(null) }
                var loginNotice by remember { mutableStateOf<String?>(null) }
                var registerError by remember { mutableStateOf<String?>(null) }

                val isFemale = currentUser?.gender != "male"
                val userRecords = records.filter { it.owner == currentUser?.email }
                val today = todayDate()

                // ----- แจ้งเตือน -----
                // วันที่ (key) ที่ผู้ใช้เปิดอ่านแจ้งเตือนแล้ว ใช้ตัดสินจุดแดง
                val readNotifDays = remember { mutableStateListOf<String>() }
                val todayKey = "${currentUser?.email}-${today.yearBE}-${today.month}-${today.day}"
                val doneToday = userRecords.any {
                    it.yearBE == today.yearBE && it.month == today.month && it.day == today.day
                }
                val notifications: List<AppNotification> =
                    if (currentUser != null && !doneToday) {
                        listOf(
                            AppNotification(
                                "แจ้งเตือนการบันทึก:",
                                "วันนี้คุณเป็นยังไงบ้าง? อย่าลืมเข้ามาบอก/บันทึกกับเรานะ 💗",
                                "${today.day}/${today.month + 1}/${today.yearBE % 100}"
                            )
                        )
                    } else emptyList()
                val hasUnread = notifications.isNotEmpty() && todayKey !in readNotifDays

                fun openBell(from: String) {
                    pageBeforeBell = from
                    if (todayKey !in readNotifDays) readNotifDays.add(todayKey)
                    page = "notification"
                }

                fun todayIndex(): Int = records.indexOfFirst {
                    it.owner == currentUser?.email &&
                            it.yearBE == today.yearBE && it.month == today.month && it.day == today.day
                }

                fun updateToday(create: () -> DiaryRecord, update: (DiaryRecord) -> DiaryRecord) {
                    val idx = todayIndex()
                    if (idx >= 0) records[idx] = update(records[idx]) else records.add(create())
                }

                when (page) {
                    "login" -> LoginScreen(
                        errorMessage = loginError,
                        noticeMessage = loginNotice,
                        onLoginClick = { user, pass ->
                            val u = user.trim().lowercase()
                            val digits = u.filter { it.isDigit() }
                            val found = accounts.firstOrNull {
                                (it.email.lowercase() == u || (digits.isNotEmpty() && it.phone == digits)) &&
                                        it.password == pass
                            }
                            if (found != null) {
                                currentUser = found
                                loginError = null
                                loginNotice = null
                                welcomeShown = false
                                page = "home"
                            } else {
                                loginNotice = null
                                loginError = "อีเมล/เบอร์โทรศัพท์ หรือรหัสผ่านไม่ถูกต้อง"
                            }
                        },
                        onRegisterClick = {
                            loginError = null
                            loginNotice = null
                            registerError = null
                            page = "register"
                        },
                        onForgotClick = {
                            loginError = null
                            loginNotice = null
                            resetEmail = null
                            page = "forgot"
                        }
                    )
                    "register" -> RegisterScreen(
                        errorMessage = registerError,
                        onRegisterClick = { name, phone, email, gender, password ->
                            val duplicated = accounts.any {
                                it.email.equals(email, ignoreCase = true) || it.phone == phone
                            }
                            if (duplicated) {
                                registerError = "อีเมลหรือเบอร์โทรศัพท์นี้ถูกใช้สมัครแล้ว"
                            } else {
                                accounts.add(Account(name, phone, email, gender, password))
                                registerError = null
                                loginError = null
                                loginNotice = "สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ"
                                page = "login"
                            }
                        },
                        onLoginClick = { registerError = null; page = "login" }
                    )
                    "forgot" -> ForgotPasswordScreen(
                        onVerify = { email, phone ->
                            val acc = accounts.firstOrNull {
                                it.email.equals(email, ignoreCase = true) && it.phone == phone
                            }
                            resetEmail = acc?.email
                            acc != null
                        },
                        onResetPassword = { newPass ->
                            val idx = accounts.indexOfFirst {
                                it.email.equals(resetEmail, ignoreCase = true)
                            }
                            if (idx >= 0) {
                                accounts[idx] = accounts[idx].copy(password = newPass)
                            }
                            resetEmail = null
                            loginError = null
                            loginNotice = "เปลี่ยนรหัสผ่านสำเร็จ กรุณาเข้าสู่ระบบด้วยรหัสผ่านใหม่"
                            page = "login"
                        },
                        onBack = { resetEmail = null; page = "login" }
                    )
                    "notification" -> NotificationScreen(
                        notifications = notifications,
                        onClose = { page = pageBeforeBell }
                    )
                    "mood" -> MoodScreen(
                        isFemale = isFemale,
                        dateText = today.fullText,
                        streak = calcStreak(userRecords),
                        onClose = { page = "home" },
                        onSave = { mood, note, period ->
                            val owner = currentUser?.email ?: ""
                            updateToday(
                                create = {
                                    DiaryRecord(
                                        owner = owner, yearBE = today.yearBE, month = today.month,
                                        day = today.day, mood = mood, note = note, period = period
                                    )
                                },
                                update = { it.copy(mood = mood, note = note, period = period) }
                            )
                            page = "photo"
                        }
                    )
                    "photo" -> SkyPhotoScreen(
                        dateText = today.slashText,
                        onSkip = { page = "behavior" },
                        onSend = { bmp ->
                            val idx = todayIndex()
                            if (idx >= 0) records[idx] = records[idx].copy(photo = bmp)
                            page = "behavior"
                        }
                    )
                    "behavior" -> BehaviorScreen(
                        dateText = today.slashText,
                        onSave = { bed, wake, minutes, food, water, activities ->
                            val idx = todayIndex()
                            if (idx >= 0) {
                                records[idx] = records[idx].copy(
                                    bedTime = bed, wakeTime = wake, sleepMinutes = minutes,
                                    food = food, waterMl = water, activities = activities
                                )
                            }
                            page = "home"
                        },
                        onSkip = { page = "home" }
                    )
                    "calendar" -> CalendarScreen(
                        records = userRecords,
                        isFemale = isFemale,
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("calendar") },
                        hasUnread = hasUnread
                    )
                    "summary" -> SummaryScreen(
                        records = userRecords,
                        isFemale = isFemale,
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("summary") },
                        hasUnread = hasUnread
                    )
                    "profile" -> ProfileScreen(
                        name = currentUser?.name ?: "",
                        email = currentUser?.email ?: "",
                        phone = currentUser?.phone ?: "",
                        password = currentUser?.password ?: "",
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("profile") },
                        hasUnread = hasUnread,
                        onLogout = {
                            currentUser = null
                            loginNotice = null
                            page = "login"
                        }
                    )
                    else -> HomeScreen(
                        records = userRecords,
                        showWelcome = !welcomeShown,
                        onCloseWelcome = { welcomeShown = true },
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("home") },
                        hasUnread = hasUnread
                    )
                }
            }
        }
    }
}