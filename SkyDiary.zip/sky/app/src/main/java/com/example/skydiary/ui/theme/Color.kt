package com.example.skydiary.ui.theme

import androidx.compose.ui.graphics.Color

val SkyBackground = Color(0xFFBDE0FF)
val SkyCard = Color(0xFFE6F1FF)
val SkyField = Color(0xFFE3EFFF)
val SkyBorder = Color(0xFF6DAAF5)
val SkyPrimary = Color(0xFF3A72EE)
val SkyLink = Color(0xFF3A6FE0)
val SkyTitle = Color(0xFF4A78D0)
val SkyDanger = Color(0xFFFF5C5C)
val SkyHint = Color(0xFF8A8A8A)
val SkyText = Color(0xFF111111)