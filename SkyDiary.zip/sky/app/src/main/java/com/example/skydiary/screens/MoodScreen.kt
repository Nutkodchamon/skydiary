package com.example.skydiary.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.skydiary.components.*
import com.example.skydiary.ui.theme.*

private data class Mood(val key: String, val icon: String, val label: String)

private val moods = listOf(
    Mood("happy", "☀️", "มีความสุข"),
    Mood("sad", "🌧️", "เศร้า , เสียใจ"),
    Mood("scared", "⛅", "กลัว"),
    Mood("angry", "⚡", "โกรธ"),
    Mood("confused", "🌪️", "วุ่นวายใจ")
)

@Composable
fun MoodScreen(
    isFemale: Boolean = true,
    onClose: () -> Unit = {},
    onSave: (mood: String, note: String, period: String?) -> Unit = { _, _, _ -> }
) {
    var selected by remember { mutableStateOf<Mood?>(null) }
    var note by remember { mutableStateOf("") }
    var period by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SkyBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "✕",
            modifier = Modifier.align(Alignment.End).clickable { onClose() },
            fontSize = 24.sp, color = SkyDanger
        )
        Text(
            "SkyDiary",
            modifier = Modifier.align(Alignment.Start),
            fontFamily = Prompt, fontWeight = FontWeight.Bold, fontSize = 30.sp, color = SkyText
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "วันนี้คุณรู้สึกยังไงบ้าง?",
            fontFamily = Prompt, fontSize = 26.sp, color = SkyText, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(8.dp, RoundedCornerShape(32.dp))
                .background(SkyCard, RoundedCornerShape(32.dp))
                .padding(20.dp)
        ) {
            Text("วันที่ 11 เมษายน 2569", fontFamily = Prompt, fontSize = 15.sp, color = SkyText)
            Spacer(Modifier.height(8.dp))
            Text("🔥 บันทึกต่อเนื่อง 10 วัน", fontFamily = Prompt, fontSize = 15.sp, color = SkyText)
            Spacer(Modifier.height(8.dp))
            Text("โปรดเลือกสภาพอากาศภายในใจของคุณ", fontFamily = Prompt, fontSize = 14.sp, color = SkyText)
            Spacer(Modifier.height(12.dp))

            MoodWheel(
                selected = selected,
                onSelect = { selected = it },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(Modifier.height(16.dp))
            Text("โน้ตประจำวัน", fontFamily = Prompt, fontSize = 15.sp, color = SkyText)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                shape = RoundedCornerShape(16.dp),
                placeholder = { Text("เริ่มพิมพ์สิ่งที่อยากเล่าตรงนี้สิ", fontFamily = Prompt, color = SkyHint) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFD8E8FF),
                    unfocusedContainerColor = Color(0xFFD8E8FF),
                    focusedBorderColor = SkyBorder,
                    unfocusedBorderColor = SkyBorder
                )
            )
        }

        if (isFemale) {
            Spacer(Modifier.height(16.dp))
            Text(
                "รอบประจำเดือน:",
                modifier = Modifier.align(Alignment.Start),
                fontFamily = Prompt, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = SkyTitle
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFC4E0FF), RoundedCornerShape(28.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PeriodOption("🙂", "มาปกติ", period == "normal", Modifier.weight(1f)) { period = "normal" }
                PeriodOption("😟", "มาผิดปกติ", period == "abnormal", Modifier.weight(1f)) { period = "abnormal" }
                PeriodOption("🚫", "ยังไม่ถึงรอบเดือน", period == "none", Modifier.weight(1f)) { period = "none" }
            }
        }

        Spacer(Modifier.height(20.dp))
        SkyButton(
            "บันทึก",
            onClick = { onSave(selected?.key ?: "", note, period) }
        )
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun MoodWheel(selected: Mood?, onSelect: (Mood) -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(280.dp)
            .background(Color(0xFFA4BDF5), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        // ตรงกลาง: แสดงอารมณ์ที่เลือก
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(selected?.icon ?: "☁️", fontSize = 56.sp)
            Text(
                selected?.label ?: "เลือกเลย",
                modifier = Modifier
                    .background(Color(0xFFB57BFF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                fontFamily = Prompt, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = SkyText
            )
        }
        // 5 อารมณ์เรียงรอบวง
        val positions = listOf(
            Alignment.TopCenter, Alignment.CenterEnd, Alignment.BottomEnd,
            Alignment.BottomStart, Alignment.CenterStart
        )
        moods.forEachIndexed { i, m ->
            Column(
                modifier = Modifier
                    .align(positions[i])
                    .padding(8.dp)
                    .alpha(if (selected == null || selected == m) 1f else 0.5f)
                    .clickable { onSelect(m) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(m.icon, fontSize = 36.sp)
                Text(m.label, fontFamily = Prompt, fontSize = 11.sp, color = SkyText)
            }
        }
    }
}

@Composable
private fun PeriodOption(
    icon: String,
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .background(if (selected) Color(0xFF7CB6FF) else Color.White, RoundedCornerShape(8.dp))
            .border(1.dp, SkyBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 30.sp)
        Text(label, fontFamily = Prompt, fontSize = 12.sp, color = SkyText, textAlign = TextAlign.Center)
    }
}

@Preview(showBackground = true, widthDp = 402, heightDp = 1000)
@Composable
fun MoodPreview() {
    SkyDiaryTheme { MoodScreen() }
}