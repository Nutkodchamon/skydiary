package com.example.skydiary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.example.skydiary.screens.HomeScreen
import com.example.skydiary.screens.LoginScreen
import com.example.skydiary.screens.MoodScreen
import com.example.skydiary.screens.RegisterScreen
import com.example.skydiary.screens.SkyPhotoScreen
import com.example.skydiary.ui.theme.SkyDiaryTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SkyDiaryTheme {
                var page by remember { mutableStateOf("login") }
                var isFemale by remember { mutableStateOf(true) }

                when (page) {
                    "login" -> LoginScreen(
                        onLoginClick = { _, _ -> page = "home" },
                        onRegisterClick = { page = "register" }
                    )
                    "register" -> RegisterScreen(
                        onRegisterClick = { page = "home" },
                        onLoginClick = { page = "login" }
                    )
                    "mood" -> MoodScreen(
                        isFemale = isFemale,
                        onClose = { page = "home" },
                        onSave = { _, _, _ -> page = "photo" }
                    )
                    "photo" -> SkyPhotoScreen(
                        onSkip = { page = "home" },
                        onSend = { page = "home" }
                    )
                    else -> HomeScreen(
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" }
                    )
                }
            }
        }
    }
}