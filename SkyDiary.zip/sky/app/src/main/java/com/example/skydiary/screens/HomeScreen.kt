package com.example.skydiary.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.skydiary.components.*
import com.example.skydiary.ui.theme.*

data class DiaryEntry(
    val date: String,
    val mood: String,
    val title: String,
    val details: List<String>,
    val color: Color
)

private val sampleEntries = listOf(
    DiaryEntry(
        "10/4/69", "scared", "วันนี้ฉันรู้สึกเหนื่อยๆ นอยๆ",
        listOf("นอนรวม 8 ชม.", "ทานอาหารได้น้อย", "ดื่มน้ำ 2000 มล.", "ไปออกกำลังกาย"),
        Color(0xFFC98BFF)
    ),
    DiaryEntry(
        "9/4/69", "happy", "วันนี้ได้ไปเที่ยว ได้ไปกินของอร่อย",
        listOf("นอนรวม 8 ชม.", "ทานอาหารเยอะ", "ดื่มน้ำ 1500 มล.", "ไปทำ workshop วาดรูป"),
        Color(0xFFFFFBC8)
    ),
    DiaryEntry(
        "8/4/69", "happy", "วันนี้ไปสวนสาธารณะ",
        listOf("นอนรวม 7 ชม.", "ทานอาหารครบ 3 มื้อ", "ดื่มน้ำ 1800 มล."),
        Color(0xFFFFFBC8)
    )
)

@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit = {},
    onAddClick: () -> Unit = {},
    onBellClick: () -> Unit = {}
) {
    var showWelcome by remember { mutableStateOf(true) }

    Box(modifier = Modifier.fillMaxSize().background(SkyBackground)) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Spacer(Modifier.width(32.dp))
                Text(
                    "‹  เมษายน 2569  ›",
                    fontFamily = Prompt, fontWeight = FontWeight.Bold,
                    fontSize = 24.sp, color = SkyText
                )
                Text("🔔", fontSize = 26.sp, modifier = Modifier.clickable { onBellClick() })
            }

            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(sampleEntries) { EntryCard(it) }
            }

            BottomBar(current = "home", onNavigate = onNavigate, onAddClick = onAddClick)
        }

        if (showWelcome) WelcomePopup(onClose = { showWelcome = false })
    }
}

@Composable
private fun EntryCard(e: DiaryEntry) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(28.dp))
            .background(e.color, RoundedCornerShape(28.dp))
            .padding(18.dp)
    ) {
        Text(
            e.date,
            modifier = Modifier.align(Alignment.End),
            fontFamily = Prompt, fontSize = 13.sp, color = SkyText
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            MoodIcon(e.mood, size = 64.dp)
            Spacer(Modifier.width(12.dp))
            Text(
                ": ${e.title}",
                fontFamily = Prompt, fontSize = 20.sp, color = SkyText
            )
        }
        Spacer(Modifier.height(8.dp))
        e.details.forEach {
            Text("• $it", fontFamily = Prompt, fontSize = 16.sp, color = SkyText)
        }
    }
}

@Composable
private fun WelcomePopup(onClose: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66FFFFFF))
            .clickable(enabled = true, onClick = {}),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .shadow(8.dp, RoundedCornerShape(28.dp))
                .background(SkyCard, RoundedCornerShape(28.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "✕",
                modifier = Modifier.align(Alignment.End).clickable { onClose() },
                fontSize = 20.sp, color = SkyDanger
            )
            Text("SkyDiary", fontFamily = Prompt, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = SkyText)
            Spacer(Modifier.height(8.dp))
            Text("ยินดีต้อนรับ!", fontFamily = Prompt, fontSize = 13.sp, color = SkyText)
            Spacer(Modifier.height(12.dp))
            Text(
                "วันนี้สภาพอากาศภายในใจของคุณเป็นอย่างไร?",
                fontFamily = Prompt, fontSize = 20.sp, color = SkyText,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "** อย่าลืมมาบอกเราน่ะ **",
                fontFamily = Prompt, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SkyText
            )
        }
    }
}

@Preview(showBackground = true, widthDp = 402, heightDp = 874)
@Composable
fun HomePreview() {
    SkyDiaryTheme { HomeScreen() }
}