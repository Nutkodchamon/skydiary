
package com.example.skydiary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.example.skydiary.screens.CalendarScreen
import com.example.skydiary.screens.HomeScreen
import com.example.skydiary.screens.LoginScreen
import com.example.skydiary.screens.MoodScreen
import com.example.skydiary.screens.ProfileScreen
import com.example.skydiary.screens.RegisterScreen
import com.example.skydiary.screens.SkyPhotoScreen
import com.example.skydiary.screens.SummaryScreen
import com.example.skydiary.ui.theme.SkyDiaryTheme

// บัญชีผู้ใช้ที่สมัครไว้ (เก็บในหน่วยความจำ หายเมื่อปิดแอป)
// ตอนมี database ให้แทนที่ด้วยการเรียกเซิร์ฟเวอร์
data class Account(
    val name: String,
    val phone: String,
    val email: String,
    val gender: String,
    val password: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SkyDiaryTheme {
                val accounts = remember { mutableStateListOf<Account>() }
                var currentUser by remember { mutableStateOf<Account?>(null) }

                var page by remember { mutableStateOf("login") }
                var loginError by remember { mutableStateOf<String?>(null) }
                var loginNotice by remember { mutableStateOf<String?>(null) }
                var registerError by remember { mutableStateOf<String?>(null) }

                val isFemale = currentUser?.gender != "male"

                when (page) {
                    "login" -> LoginScreen(
                        errorMessage = loginError,
                        noticeMessage = loginNotice,
                        onLoginClick = { user, pass ->
                            val u = user.trim().lowercase()
                            val digits = u.filter { it.isDigit() }
                            val found = accounts.firstOrNull {
                                (it.email.lowercase() == u || (digits.isNotEmpty() && it.phone == digits)) &&
                                        it.password == pass
                            }
                            if (found != null) {
                                currentUser = found
                                loginError = null
                                loginNotice = null
                                page = "home"
                            } else {
                                loginNotice = null
                                loginError = "อีเมล/เบอร์โทรศัพท์ หรือรหัสผ่านไม่ถูกต้อง"
                            }
                        },
                        onRegisterClick = {
                            loginError = null
                            loginNotice = null
                            registerError = null
                            page = "register"
                        }
                    )

                    "register" -> RegisterScreen(
                        errorMessage = registerError,
                        onRegisterClick = { name, phone, email, gender, password ->
                            val duplicated = accounts.any {
                                it.email.equals(email, ignoreCase = true) || it.phone == phone
                            }
                            if (duplicated) {
                                registerError = "อีเมลหรือเบอร์โทรศัพท์นี้ถูกใช้สมัครแล้ว"
                            } else {
                                accounts.add(Account(name, phone, email, gender, password))
                                registerError = null
                                loginError = null
                                loginNotice = "สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ"
                                page = "login"
                            }
                        },
                        onLoginClick = { registerError = null; page = "login" }
                    )

                    "mood" -> MoodScreen(
                        isFemale = isFemale,
                        onClose = { page = "home" },
                        onSave = { _, _, _ -> page = "photo" }
                    )

                    "photo" -> SkyPhotoScreen(
                        onSkip = { page = "home" },
                        onSend = { page = "home" }
                    )

                    "calendar" -> CalendarScreen(
                        isFemale = isFemale,
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" }
                    )

                    "summary" -> SummaryScreen(
                        isFemale = isFemale,
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" }
                    )

                    "profile" -> ProfileScreen(
                        name = currentUser?.name ?: "",
                        email = currentUser?.email ?: "",
                        phone = currentUser?.phone ?: "",
                        password = currentUser?.password ?: "",
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onLogout = {
                            currentUser = null
                            loginNotice = null
                            page = "login"
                        }
                    )

                    else -> HomeScreen(
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" }
                    )
                }
            }
        }
    }
}
