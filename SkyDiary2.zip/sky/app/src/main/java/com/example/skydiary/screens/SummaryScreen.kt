package com.example.skydiary.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.skydiary.components.*
import com.example.skydiary.ui.theme.*

data class MoodSlice(val label: String, val percent: Int, val color: Color)

private val sampleSlices = listOf(
    MoodSlice("มีความสุข", 20, Color(0xFFFFDD57)),
    MoodSlice("เศร้า", 40, Color(0xFFB394F5)),
    MoodSlice("กลัว", 20, Color(0xFFF2B56B)),
    MoodSlice("โกรธ", 20, Color(0xFF4F7DF3))
)

@Composable
fun SummaryScreen(
    isFemale: Boolean = true,
    onNavigate: (String) -> Unit = {},
    onAddClick: () -> Unit = {},
    onBellClick: () -> Unit = {}
) {
    var month by remember { mutableStateOf(YearMonth(2569, 3)) } // เมษายน 2569

    // ข้อมูลตัวอย่างมีเฉพาะเมษายน 2569 ภายหลังดึงจากฐานข้อมูลตาม month.key
    val hasData = month.key == "2569-04"

    Column(modifier = Modifier.fillMaxSize().background(SkyBackground)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Text(
                "สรุปผลรายเดือน",
                modifier = Modifier
                    .align(Alignment.Center)
                    .shadow(4.dp, RoundedCornerShape(20.dp))
                    .background(Color(0xFFE6F1FF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 28.dp, vertical = 14.dp),
                fontFamily = Prompt, fontWeight = FontWeight.Bold,
                fontSize = 20.sp, color = SkyText
            )
            Text(
                "🔔", fontSize = 26.sp,
                modifier = Modifier.align(Alignment.CenterEnd).clickable { onBellClick() }
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
        ) {
            MonthPicker(
                value = month,
                onChange = { month = it },
                fontSize = 18,
                modifier = Modifier
                    .shadow(4.dp, RoundedCornerShape(12.dp))
                    .background(Color(0xFFE6F1FF), RoundedCornerShape(12.dp))
                    .padding(vertical = 6.dp)
            )

            if (!hasData) {
                Spacer(Modifier.height(80.dp))
                Text(
                    "ยังไม่มีข้อมูลในเดือนนี้",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    fontFamily = Prompt, fontSize = 18.sp, color = SkyHint
                )
            } else {
                Spacer(Modifier.height(14.dp))
                SectionTitle("อารมณ์:")
                Spacer(Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(6.dp, RoundedCornerShape(24.dp))
                        .background(Color.White, RoundedCornerShape(24.dp))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PieChart(sampleSlices, modifier = Modifier.size(140.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "คุณมีภาพรวมอารมณ์ในเดือนนี้ :",
                            fontFamily = Prompt, fontWeight = FontWeight.Bold,
                            fontSize = 14.sp, color = SkyText, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "กลัว,นอย,เหนื่อย,\nไม่สบายใจ",
                            modifier = Modifier
                                .shadow(4.dp, RoundedCornerShape(16.dp))
                                .background(Color(0xFFC98BFF), RoundedCornerShape(16.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            fontFamily = Prompt, fontSize = 13.sp, color = SkyText,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        SectionTitle("การนอนหลับ:")
                        Spacer(Modifier.height(6.dp))
                        InfoCard("🛏️", "การนอนดี\nนอนครบ 8 ชม/คืน")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        SectionTitle("การทานอาหาร:")
                        Spacer(Modifier.height(6.dp))
                        InfoCard("🍽️", "ทานอาหารได้ดี")
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        SectionTitle("การดื่มน้ำ:")
                        Spacer(Modifier.height(6.dp))
                        InfoCard("🥛", "ดื่มน้ำได้ดี\nดื่มน้ำได้ 1,500 มล./วัน")
                    }
                    if (isFemale) {
                        Column(modifier = Modifier.weight(1f)) {
                            Spacer(Modifier.height(26.dp))
                            InfoCard("🩸", "วันนี้คุณมีประจำเดือน")
                        }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
        }

        BottomBar(current = "summary", onNavigate = onNavigate, onAddClick = onAddClick)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontFamily = Prompt, fontWeight = FontWeight.Bold,
        fontSize = 18.sp, color = SkyTitle
    )
}

@Composable
private fun InfoCard(icon: String?, text: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .shadow(6.dp, RoundedCornerShape(24.dp))
            .background(Color.White, RoundedCornerShape(24.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Text(icon, fontSize = 48.sp)
            Spacer(Modifier.height(8.dp))
        }
        Text(
            text,
            fontFamily = Prompt, fontWeight = FontWeight.Bold,
            fontSize = 13.sp, color = SkyText, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun PieChart(slices: List<MoodSlice>, modifier: Modifier = Modifier) {
    val total = slices.sumOf { it.percent }.coerceAtLeast(1)
    Canvas(modifier = modifier) {
        var startAngle = -90f
        slices.forEach { s ->
            val sweep = 360f * s.percent / total
            drawArc(
                color = s.color,
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = true,
                size = Size(size.width, size.height)
            )
            startAngle += sweep
        }
    }
}

@Preview(showBackground = true, widthDp = 402, heightDp = 874)
@Composable
fun SummaryPreview() {
    SkyDiaryTheme { SummaryScreen() }
}