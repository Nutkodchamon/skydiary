package com.example.skydiary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.example.skydiary.components.DASS_TRIGGER_DAYS
import com.example.skydiary.components.DiaryRecord
import com.example.skydiary.components.calcSadStreak
import com.example.skydiary.components.calcStreak
import com.example.skydiary.components.dateCode
import com.example.skydiary.components.todayDate
import com.example.skydiary.screens.AppNotification
import com.example.skydiary.screens.BehaviorScreen
import com.example.skydiary.screens.CalendarScreen
import com.example.skydiary.screens.DassResultScreen
import com.example.skydiary.screens.DassScreen
import com.example.skydiary.screens.ForgotPasswordScreen
import com.example.skydiary.screens.HomeScreen
import com.example.skydiary.screens.LoginScreen
import com.example.skydiary.screens.MoodScreen
import com.example.skydiary.screens.NotificationScreen
import com.example.skydiary.screens.ProfileScreen
import com.example.skydiary.screens.RegisterScreen
import com.example.skydiary.screens.SkyPhotoScreen
import com.example.skydiary.screens.SummaryScreen
import com.example.skydiary.ui.theme.SkyDiaryTheme

// บัญชีผู้ใช้ (เก็บในหน่วยความจำ หายเมื่อปิดแอป) ตอนมี database ให้แทนที่ด้วยการเรียกเซิร์ฟเวอร์
data class Account(
    val name: String,
    val phone: String,
    val email: String,
    val gender: String,
    val password: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SkyDiaryTheme {
                val accounts = remember { mutableStateListOf<Account>() }
                val records = remember { mutableStateListOf<DiaryRecord>() }
                var currentUser by remember { mutableStateOf<Account?>(null) }
                var resetEmail by remember { mutableStateOf<String?>(null) }
                var welcomeShown by remember { mutableStateOf(false) }

                var page by remember { mutableStateOf("login") }
                var pageBeforeBell by remember { mutableStateOf("home") }
                var loginError by remember { mutableStateOf<String?>(null) }
                var loginNotice by remember { mutableStateOf<String?>(null) }
                var registerError by remember { mutableStateOf<String?>(null) }

                val isFemale = currentUser?.gender != "male"
                val userRecords = records.filter { it.owner == currentUser?.email }
                val today = todayDate()

                // ----- DASS-21 -----
                // วันที่ทำแบบประเมินล่าสุดของแต่ละบัญชี (dateCode) หลังทำแล้วต้องเศร้าครบรอบใหม่ถึงจะแนะนำอีก
                val dassDone = remember { mutableStateMapOf<String, Int>() }
                var dassAnswers by remember { mutableStateOf<List<Int>>(emptyList()) }
                var dassPopupDismissed by remember { mutableStateOf(false) }
                val lastDass = currentUser?.email?.let { dassDone[it] } ?: 0
                val dassEligible = currentUser != null &&
                        calcSadStreak(userRecords, lastDass) >= DASS_TRIGGER_DAYS

                // ----- แจ้งเตือน -----
                val readNotifKeys = remember { mutableStateListOf<String>() }
                val todayKey = "${currentUser?.email}-${today.yearBE}-${today.month}-${today.day}"
                val dassKey = "$todayKey-dass"
                val doneToday = userRecords.any {
                    it.yearBE == today.yearBE && it.month == today.month && it.day == today.day
                }
                val dateText = "${today.day}/${today.month + 1}/${today.yearBE % 100}"

                val notifications = buildList<AppNotification> {
                    if (dassEligible) {
                        add(
                            AppNotification(
                                title = "ข้อเสนอแนะการทำแบบประเมิน",
                                message = "เราเห็นว่าคุณบันทึกอารมณ์เศร้าติดต่อกันหลายวัน อยากลองทำแบบประเมินอารมณ์เบื้องต้น (DASS-21) ไหม?",
                                dateText = dateText,
                                onClick = { page = "dass" },
                                actionText = "ทำแบบประเมิน ›"
                            )
                        )
                    }
                    if (currentUser != null && !doneToday) {
                        add(
                            AppNotification(
                                "แจ้งเตือนการบันทึก:",
                                "วันนี้คุณเป็นยังไงบ้าง? อย่าลืมเข้ามาบอก/บันทึกกับเรานะ 💗",
                                dateText
                            )
                        )
                    }
                }
                val hasUnread =
                    (dassEligible && dassKey !in readNotifKeys) ||
                            (currentUser != null && !doneToday && todayKey !in readNotifKeys)

                fun openBell(from: String) {
                    pageBeforeBell = from
                    if (todayKey !in readNotifKeys) readNotifKeys.add(todayKey)
                    if (dassKey !in readNotifKeys) readNotifKeys.add(dassKey)
                    page = "notification"
                }

                fun todayIndex(): Int = records.indexOfFirst {
                    it.owner == currentUser?.email &&
                            it.yearBE == today.yearBE && it.month == today.month && it.day == today.day
                }

                fun updateToday(create: () -> DiaryRecord, update: (DiaryRecord) -> DiaryRecord) {
                    val idx = todayIndex()
                    if (idx >= 0) records[idx] = update(records[idx]) else records.add(create())
                }

                when (page) {
                    "login" -> LoginScreen(
                        errorMessage = loginError,
                        noticeMessage = loginNotice,
                        onLoginClick = { user, pass ->
                            val u = user.trim().lowercase()
                            val digits = u.filter { it.isDigit() }
                            val found = accounts.firstOrNull {
                                (it.email.lowercase() == u || (digits.isNotEmpty() && it.phone == digits)) &&
                                        it.password == pass
                            }
                            if (found != null) {
                                currentUser = found
                                loginError = null
                                loginNotice = null
                                welcomeShown = false
                                dassPopupDismissed = false
                                page = "home"
                            } else {
                                loginNotice = null
                                loginError = "อีเมล/เบอร์โทรศัพท์ หรือรหัสผ่านไม่ถูกต้อง"
                            }
                        },
                        onRegisterClick = {
                            loginError = null
                            loginNotice = null
                            registerError = null
                            page = "register"
                        },
                        onForgotClick = {
                            loginError = null
                            loginNotice = null
                            resetEmail = null
                            page = "forgot"
                        }
                    )
                    "register" -> RegisterScreen(
                        errorMessage = registerError,
                        onRegisterClick = { name, phone, email, gender, password ->
                            val duplicated = accounts.any {
                                it.email.equals(email, ignoreCase = true) || it.phone == phone
                            }
                            if (duplicated) {
                                registerError = "อีเมลหรือเบอร์โทรศัพท์นี้ถูกใช้สมัครแล้ว"
                            } else {
                                accounts.add(Account(name, phone, email, gender, password))
                                registerError = null
                                loginError = null
                                loginNotice = "สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ"
                                page = "login"
                            }
                        },
                        onLoginClick = { registerError = null; page = "login" }
                    )
                    "forgot" -> ForgotPasswordScreen(
                        onVerify = { email, phone ->
                            val acc = accounts.firstOrNull {
                                it.email.equals(email, ignoreCase = true) && it.phone == phone
                            }
                            resetEmail = acc?.email
                            acc != null
                        },
                        onResetPassword = { newPass ->
                            val idx = accounts.indexOfFirst {
                                it.email.equals(resetEmail, ignoreCase = true)
                            }
                            if (idx >= 0) {
                                accounts[idx] = accounts[idx].copy(password = newPass)
                            }
                            resetEmail = null
                            loginError = null
                            loginNotice = "เปลี่ยนรหัสผ่านสำเร็จ กรุณาเข้าสู่ระบบด้วยรหัสผ่านใหม่"
                            page = "login"
                        },
                        onBack = { resetEmail = null; page = "login" }
                    )
                    "notification" -> NotificationScreen(
                        notifications = notifications,
                        onClose = { page = pageBeforeBell }
                    )
                    "dass" -> DassScreen(
                        onClose = { page = "home" },
                        onSubmit = { answers ->
                            dassAnswers = answers
                            currentUser?.email?.let {
                                dassDone[it] = dateCode(today.yearBE, today.month, today.day)
                            }
                            page = "dassResult"
                        }
                    )
                    "dassResult" -> DassResultScreen(
                        answers = dassAnswers,
                        onClose = { page = "home" }
                    )
                    "mood" -> MoodScreen(
                        isFemale = isFemale,
                        dateText = today.fullText,
                        streak = calcStreak(userRecords),
                        onClose = { page = "home" },
                        onSave = { mood, note, period ->
                            val owner = currentUser?.email ?: ""
                            updateToday(
                                create = {
                                    DiaryRecord(
                                        owner = owner, yearBE = today.yearBE, month = today.month,
                                        day = today.day, mood = mood, note = note, period = period
                                    )
                                },
                                update = { it.copy(mood = mood, note = note, period = period) }
                            )
                            page = "photo"
                        }
                    )
                    "photo" -> SkyPhotoScreen(
                        dateText = today.slashText,
                        onSkip = { page = "behavior" },
                        onSend = { bmp ->
                            val idx = todayIndex()
                            if (idx >= 0) records[idx] = records[idx].copy(photo = bmp)
                            page = "behavior"
                        }
                    )
                    "behavior" -> BehaviorScreen(
                        dateText = today.slashText,
                        onSave = { bed, wake, minutes, food, water, activities ->
                            val idx = todayIndex()
                            if (idx >= 0) {
                                records[idx] = records[idx].copy(
                                    bedTime = bed, wakeTime = wake, sleepMinutes = minutes,
                                    food = food, waterMl = water, activities = activities
                                )
                            }
                            page = "home"
                        },
                        onSkip = { page = "home" }
                    )
                    "calendar" -> CalendarScreen(
                        records = userRecords,
                        isFemale = isFemale,
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("calendar") },
                        hasUnread = hasUnread
                    )
                    "summary" -> SummaryScreen(
                        records = userRecords,
                        isFemale = isFemale,
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("summary") },
                        hasUnread = hasUnread
                    )
                    "profile" -> ProfileScreen(
                        name = currentUser?.name ?: "",
                        email = currentUser?.email ?: "",
                        phone = currentUser?.phone ?: "",
                        password = currentUser?.password ?: "",
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("profile") },
                        hasUnread = hasUnread,
                        onLogout = {
                            currentUser = null
                            loginNotice = null
                            page = "login"
                        }
                    )
                    else -> HomeScreen(
                        records = userRecords,
                        showWelcome = !welcomeShown,
                        onCloseWelcome = { welcomeShown = true },
                        showDassBanner = dassEligible,
                        showDassPopup = dassEligible && !dassPopupDismissed,
                        onDassStart = { dassPopupDismissed = true; page = "dass" },
                        onDassDismiss = { dassPopupDismissed = true },
                        onNavigate = { page = it },
                        onAddClick = { page = "mood" },
                        onBellClick = { openBell("home") },
                        hasUnread = hasUnread
                    )
                }
            }
        }
    }
}