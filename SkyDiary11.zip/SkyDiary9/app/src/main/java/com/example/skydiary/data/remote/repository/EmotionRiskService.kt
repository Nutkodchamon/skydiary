package com.example.skydiary.data.remote.repository

import com.example.skydiary.components.DiaryRecord
import java.time.LocalDate

/** Evaluates a consecutive 14-day negative-mood streak using actual calendar dates. */
class EmotionRiskService(private val notifications: NotificationRepository = NotificationRepository()) {
    fun hasFourteenNegativeDays(records: List<DiaryRecord>, today: LocalDate = LocalDate.now()): Boolean {
        val negative = setOf("sad", "scared", "angry", "confused")
        val byDate = records.associateBy { LocalDate.of(it.yearBE - 543, it.month + 1, it.day) }
        return (0L..13L).all { offset -> byDate[today.minusDays(offset)]?.mood in negative }
    }

    /** Call after successfully saving/loading the authenticated user's records. */
    suspend fun checkAndNotify(records: List<DiaryRecord>, today: LocalDate = LocalDate.now()): Boolean {
        val atRisk = hasFourteenNegativeDays(records, today)
        if (atRisk) notifications.addScreeningReminderIfAbsent()
        return atRisk
    }
}
